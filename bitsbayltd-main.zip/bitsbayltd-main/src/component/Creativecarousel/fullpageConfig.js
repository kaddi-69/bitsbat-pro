export default {
  callbacks: ["onLeave"],
  // licenseKey: "OPEN-SOURCE-GPLV3-LICENSE",
  anchors: ["Hero", "About", "Team", "Contact"],
  navigation: true,
  navigationPosition: "left",
  scrollOverflow: true,
  arrowNavigation: true,
};
